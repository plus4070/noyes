#include "../../include/Status/WaitSet.h"

namespace CNU_DDS
{
	ReturnCode_t	attach_condition(Condition* a_condition)
	{
		ReturnCode_t	result;

		return result;
	}

	ReturnCode_t	detach_condition(Condition* a_condition)
	{
		ReturnCode_t	result;

		return result;
	}

	ReturnCode_t	wait(ConditionSeq* active_conditions, Duration_t timeout)
	{
		ReturnCode_t	result;

		return result;
	}

	ReturnCode_t	get_conditions(ConditionSeq* attached_conditions)
	{
		ReturnCode_t	result;

		return result;
	}
}
