#include "../../../include/Qos/QosPolicy/HistoryQosPolicy.h"

namespace CNU_DDS
{
	HistoryQosPolicy::HistoryQosPolicy(void)
	{
		//name	= HISTORY_QOS_POLICY_NAME;
	}

	HistoryQosPolicy::~HistoryQosPolicy(void)
	{

	}
}
