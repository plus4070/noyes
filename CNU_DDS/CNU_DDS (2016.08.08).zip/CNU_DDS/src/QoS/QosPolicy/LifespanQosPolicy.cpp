#include "../../../include/Qos/QosPolicy/LifespanQosPolicy.h"

namespace CNU_DDS
{
	LifespanQosPolicy::LifespanQosPolicy(void)
	{
		//name	= LIFESPAN_QOS_POLICY_NAME;
	}

	LifespanQosPolicy::~LifespanQosPolicy(void)
	{

	}
}
