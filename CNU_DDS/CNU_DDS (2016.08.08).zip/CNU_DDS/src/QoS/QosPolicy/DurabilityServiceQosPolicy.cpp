#include "../../../include/Qos/QosPolicy/DurabilityServiceQosPolicy.h"

namespace CNU_DDS
{
	DurabilityServiceQosPolicy::DurabilityServiceQosPolicy(void)
	{
		//name	= DURABILITY_QOS_POLICY_NAME;
	}

	DurabilityServiceQosPolicy::~DurabilityServiceQosPolicy(void)
	{

	}
}
