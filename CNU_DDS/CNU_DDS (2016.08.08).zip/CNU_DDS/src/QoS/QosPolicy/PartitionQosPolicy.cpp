#include "../../../include/Qos/QosPolicy/PartitionQosPolicy.h"

namespace CNU_DDS
{
	PartitionQosPolicy::PartitionQosPolicy(void)
	{
		//name	= PARTITION_QOS_POLICY_NAME;
	}

	PartitionQosPolicy::~PartitionQosPolicy(void)
	{

	}
}
