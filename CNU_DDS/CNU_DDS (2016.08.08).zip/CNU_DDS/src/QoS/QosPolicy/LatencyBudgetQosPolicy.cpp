#include "../../../include/Qos/QosPolicy/LatencyBudgetQosPolicy.h"

namespace CNU_DDS
{
	LatencyBudgetQosPolicy::LatencyBudgetQosPolicy(void)
	{
		//name	= LATENCY_BUDGET_QOS_POLICY_NAME;
	}

	LatencyBudgetQosPolicy::~LatencyBudgetQosPolicy(void)
	{

	}
}
