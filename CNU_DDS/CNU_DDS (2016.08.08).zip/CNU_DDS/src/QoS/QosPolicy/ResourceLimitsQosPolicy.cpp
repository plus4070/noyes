#include "../../../include/Qos/QosPolicy/ResourceLimitsQosPolicy.h"

namespace CNU_DDS
{
	ResourceLimitsQosPolicy::ResourceLimitsQosPolicy(void)
	{
		//name	= RESOURCE_LIMITS_QOS_POLICY_NAME;
	}

	ResourceLimitsQosPolicy::~ResourceLimitsQosPolicy(void)
	{

	}
}
