#include "../../../include/Qos/QosPolicy/DurabilityQosPolicy.h"

namespace CNU_DDS
{
	DurabilityQosPolicy::DurabilityQosPolicy(void)
	{
		//name	= DURABILITY_QOS_POLICY_NAME;
	}

	DurabilityQosPolicy::~DurabilityQosPolicy(void)
	{

	}
}
