#include "../../../include/Qos/QosPolicy/OwnershipStrengthQosPolicy.h"

namespace CNU_DDS
{
	OwnershipStrengthQosPolicy::OwnershipStrengthQosPolicy(void)
	{
		//name	= OWNERSHIP_STRENGTH_QOS_POLICY_NAME;
	}

	OwnershipStrengthQosPolicy::~OwnershipStrengthQosPolicy(void)
	{

	}
}
