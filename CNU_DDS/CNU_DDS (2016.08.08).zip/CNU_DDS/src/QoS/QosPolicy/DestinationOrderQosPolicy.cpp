#include "../../../include/Qos/QosPolicy/DestinationOrderQosPolicy.h"

namespace CNU_DDS
{
	DestinationOrderQosPolicy::DestinationOrderQosPolicy(void)
	{
		//name	= DESTINAITON_ORDER_QOS_POLICY_NAME;
	}

	DestinationOrderQosPolicy::~DestinationOrderQosPolicy(void)
	{

	}
}
