#include "../../../include/Qos/QosPolicy/ReliabilityQosPolicy.h"

namespace CNU_DDS
{
	ReliabilityQosPolicy::ReliabilityQosPolicy(void)
	{
		//name	= RELIABILITY_QOS_POLICY_NAME;
	}

	ReliabilityQosPolicy::~ReliabilityQosPolicy(void)
	{

	}
}
