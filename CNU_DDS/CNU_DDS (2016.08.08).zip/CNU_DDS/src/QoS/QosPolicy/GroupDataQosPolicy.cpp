#include "../../../include/Qos/QosPolicy/GroupDataQosPolicy.h"

namespace CNU_DDS
{
	GroupDataQosPolicy::GroupDataQosPolicy(void)
	{
		//name	= GROUP_DATA_QOS_POLICY_NAME;
	}

	GroupDataQosPolicy::~GroupDataQosPolicy(void)
	{

	}
}
