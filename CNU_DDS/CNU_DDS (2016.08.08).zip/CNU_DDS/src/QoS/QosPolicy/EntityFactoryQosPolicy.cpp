#include "../../../include/Qos/QosPolicy/EntityFactoryQosPolicy.h"

namespace CNU_DDS
{
	EntityFactoryQosPolicy::EntityFactoryQosPolicy(void)
	{
		//name	= ENTITY_FACTORY_QOS_POLICY_NAME;
	}

	EntityFactoryQosPolicy::~EntityFactoryQosPolicy(void)
	{

	}
}
