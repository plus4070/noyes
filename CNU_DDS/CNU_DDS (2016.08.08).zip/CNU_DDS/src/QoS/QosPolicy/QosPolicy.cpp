#include "../../../include/Qos/QosPolicy/QosPolicy.h"

namespace CNU_DDS
{
	QosPolicy::QosPolicy(void)
	{

	}

	QosPolicy::~QosPolicy(void)
	{

	}
}
