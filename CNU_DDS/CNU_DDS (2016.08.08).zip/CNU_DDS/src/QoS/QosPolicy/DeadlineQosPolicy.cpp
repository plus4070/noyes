#include "../../../include/Qos/QosPolicy/DeadlineQosPolicy.h"

namespace CNU_DDS
{
	DeadlineQosPolicy::DeadlineQosPolicy()
	{
		//name	= DEADLINE_QOS_POLICY_NAME;
	}

	DeadlineQosPolicy::~DeadlineQosPolicy()
	{

	}
}
