#include "../../../include/Qos/QosPolicy/PresentationQosPolicy.h"

namespace CNU_DDS
{
	PresentationQosPolicy::PresentationQosPolicy(void)
	{
		//name	= PRESENTATION_QOS_POLICY_NAME;
	}

	PresentationQosPolicy::~PresentationQosPolicy(void)
	{

	}
}
