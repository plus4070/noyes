#include "../../../include/Qos/QosPolicy/UserDataQosPolicy.h"

namespace CNU_DDS
{
	UserDataQosPolicy::UserDataQosPolicy(void)
	{
		//name	= USER_DATA_QOS_POLICY_NAME;
	}

	UserDataQosPolicy::~UserDataQosPolicy(void)
	{

	}
}
