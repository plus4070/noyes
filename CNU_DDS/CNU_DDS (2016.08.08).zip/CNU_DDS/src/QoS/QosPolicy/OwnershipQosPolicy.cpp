#include "../../../include/Qos/QosPolicy/OwnershipQosPolicy.h"

namespace CNU_DDS
{
	OwnershipQosPolicy::OwnershipQosPolicy(void)
	{
		//name	= OWNERSHIP_QOS_POLICY_NAME;
	}

	OwnershipQosPolicy::~OwnershipQosPolicy(void)
	{

	}
}
