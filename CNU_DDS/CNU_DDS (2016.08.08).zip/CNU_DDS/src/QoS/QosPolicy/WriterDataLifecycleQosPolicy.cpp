#include "../../../include/Qos/QosPolicy/WriterDataLifecycleQosPolicy.h"

namespace CNU_DDS
{
	WriterDataLifecycleQosPolicy::WriterDataLifecycleQosPolicy(void)
	{
		//name	= WRITER_DATA_LIFECYCLE_QOS_POLICY_NAME;
	}

	WriterDataLifecycleQosPolicy::~WriterDataLifecycleQosPolicy(void)
	{

	}
}
