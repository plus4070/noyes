#include "../../../include/Qos/QosPolicy/LivelinessQosPolicy.h"

namespace CNU_DDS
{
	LivelinessQosPolicy::LivelinessQosPolicy(void)
	{
		//name	= LIVELINESS_QOS_POLICY_NAME;
	}

	LivelinessQosPolicy::~LivelinessQosPolicy(void)
	{

	}
}
