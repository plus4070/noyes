#include "../../../include/Qos/QosPolicy/ReaderDataLifecycleQosPolicy.h"

namespace CNU_DDS
{
	ReaderDataLifecycleQosPolicy::ReaderDataLifecycleQosPolicy(void)
	{
	//	name	= READER_DATA_LIFECYCLE_QOS_POLICY_NAME;
	}

	ReaderDataLifecycleQosPolicy::~ReaderDataLifecycleQosPolicy(void)
	{

	}
}
