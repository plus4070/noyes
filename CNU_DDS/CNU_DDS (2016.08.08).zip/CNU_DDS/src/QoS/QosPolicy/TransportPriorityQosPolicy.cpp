#include "../../../include/Qos/QosPolicy/TransportPriorityQosPolicy.h"

namespace CNU_DDS
{
	TransportPriorityQosPolicy::TransportPriorityQosPolicy(void)
	{
		//name	= TRANSPORT_PRIORITY_QOS_POLICY_NAME;
	}

	TransportPriorityQosPolicy::~TransportPriorityQosPolicy(void)
	{

	}
}
