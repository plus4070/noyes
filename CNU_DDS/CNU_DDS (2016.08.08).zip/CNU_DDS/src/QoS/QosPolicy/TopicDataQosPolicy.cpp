#include "../../../include/Qos/QosPolicy/TopicDataQosPolicy.h"

namespace CNU_DDS
{
	TopicDataQosPolicy::TopicDataQosPolicy(void)
	{
		//name	= TOPIC_DATA_QOS_POLICY_NAME;
	}

	TopicDataQosPolicy::~TopicDataQosPolicy(void)
	{

	}
}
