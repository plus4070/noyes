#include "../../../include/Qos/QosPolicy/TimeBasedFilterQosPolicy.h"

namespace CNU_DDS
{
	TimeBasedFilterQosPolicy::TimeBasedFilterQosPolicy(void)
	{
		//name	= TIME_BASED_FILTER_QOS_POLICY_NAME;
	}

	TimeBasedFilterQosPolicy::~TimeBasedFilterQosPolicy(void)
	{

	}
}
