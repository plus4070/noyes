#ifndef SUBMESSAGEELEMENT_H_
#define SUBMESSAGEELEMENT_H_

#include "../Type/ByteStream.h"

namespace CNU_DDS
{
	class SubmessageElement
	{
	public:
	};
}

#endif
