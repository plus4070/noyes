#ifndef COUNT_T_H_
#define COUNT_T_H_

namespace CNU_DDS
{
	class Count_t
	{
	public:
		long	value;
	};
}

#endif
