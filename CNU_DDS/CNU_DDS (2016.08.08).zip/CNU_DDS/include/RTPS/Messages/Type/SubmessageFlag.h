#ifndef SUBMESSAGEFLAG_H_
#define SUBMESSAGEFLAG_H_

namespace CNU_DDS
{
	typedef unsigned char	SubmessageFlag;
}

#endif
