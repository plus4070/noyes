#ifndef RTPSENTITY_H_
#define RTPSENTITY_H_

#include "Type/GUID_t.h"

namespace CNU_DDS
{
	class RTPSEntity
	{
	public:
		GUID_t				guid;
	};
}

#endif
