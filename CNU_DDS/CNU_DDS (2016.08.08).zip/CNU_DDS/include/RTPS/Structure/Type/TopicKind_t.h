#ifndef TOPICKIND_T_H_
#define TOPICKIND_T_H_

namespace CNU_DDS
{
	class TopicKind_t
	{
	public:
		long	value;
	};

	const long	NO_KEY		= 1;
	const long	WITH_KEY	= 2;
}

#endif
