#ifndef ENTITYQOS_H_
#define ENTITYQOS_H_

namespace CNU_DDS
{
	class EntityQos
	{
	public:

	};
}

#endif /* ENTITYQOS_H_ */
