#ifndef DOMAINID_T_H_
#define DOMAINID_T_H_

#include "BasicDefinitions.h"

namespace CNU_DDS
{
	typedef	DOMAINID_TYPE_NATIVE	DomainId_t;
}

#endif
