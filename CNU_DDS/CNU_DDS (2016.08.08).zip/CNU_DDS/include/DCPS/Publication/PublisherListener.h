#ifndef PUBLISHERLISTENER_H_
#define PUBLISHERLISTENER_H_

#include "../../Status/Listener.h"
#include "DataWriterListener.h"

namespace CNU_DDS
{
	class PublisherListener : public DataWriterListener
	{
	public:
	};
}

#endif
