#ifndef ENTITYSTATUS_H_
#define ENTITYSTATUS_H_

#include "../Status/InclusionsOfStatuses.h"

namespace CNU_DDS
{
	class EntityStatus
	{
	public:

	};
}

#endif
