#ifndef DOMAINPARTICIPANTSTATUS_H_
#define DOMAINPARTICIPANTSTATUS_H_

#include "../Status/InclusionsOfStatuses.h"
#include "EntityStatus.h"

namespace CNU_DDS
{
	class DomainParticipantStatus : public EntityStatus
	{
	public:

	};
}

#endif /* DOMAINPARTICIPANTSTATUS_H_ */
