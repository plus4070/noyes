#ifndef SUBSCRIBERSTATUS_H_
#define SUBSCRIBERSTATUS_H_

#include "EntityStatus.h"

namespace CNU_DDS
{
	class SubscriberStatus : public EntityStatus
	{
	public:

	};
}

#endif
