#ifndef PUBLISHERSTATUS_H_
#define PUBLISHERSTATUS_H_

#include "EntityStatus.h"

namespace CNU_DDS
{
	class PublisherStatus : public EntityStatus
	{
	public:

	};
}

#endif
