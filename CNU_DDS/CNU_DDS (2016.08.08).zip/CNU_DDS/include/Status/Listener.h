#ifndef LISTENER_H_
#define LISTENER_H_

namespace CNU_DDS
{
	class Listener
	{

	};
}

#endif
