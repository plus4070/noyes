#ifndef STATUS_H_
#define STATUS_H_

namespace CNU_DDS
{
	class Status
	{

	};
}

#endif
