#ifndef APPLICATION_TIMERTEST_H_
#define APPLICATION_TIMERTEST_H_

#include "../include/Utility/Timer/DynamicTimer.h"

namespace CNU_DDS
{
	void	TimerTest();

	void	TimerTestFunc(unsigned long arg);
}

#endif /* APPLICATION_TIMERTEST_H_ */
