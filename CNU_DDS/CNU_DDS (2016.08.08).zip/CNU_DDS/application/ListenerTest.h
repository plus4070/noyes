#ifndef APPLICATION_LISTENERTEST_H_
#define APPLICATION_LISTENERTEST_H_

namespace CNU_DDS
{
	void	ListenerTest();
}


#endif /* APPLICATION_LISTENERTEST_H_ */
