#ifndef APPLICATION_DISCOVEREDDATATEST_H_
#define APPLICATION_DISCOVEREDDATATEST_H_

namespace CNU_DDS
{
	void	DiscoveredDataTest();
	void	DiscoveredParticipantDataTest();
	void	DiscoveredPublicationDataTest();
	void	DiscoveredSubscriptionDataTest();
	void	DiscoveredTopicDataTest();
}

#endif /* APPLICATION_DISCOVEREDDATATEST_H_ */
